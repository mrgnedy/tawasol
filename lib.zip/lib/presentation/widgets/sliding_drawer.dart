import 'package:flutter/material.dart';

class SlidingDrawer extends StatefulWidget {
  @override
  _SlidingDrawerState createState() => _SlidingDrawerState();
}

class _SlidingDrawerState extends State<SlidingDrawer> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}